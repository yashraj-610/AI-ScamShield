Dataset: Dataset of 1000 Images of Malicious and Benign QR codes 2025
Creator: Sefiya Galadima
Source: https://data.mendeley.com/datasets/cmhh7744sp/1
DOI: 10.17632/cmhh7744sp.1
License: CC BY 4.0
Total images verified locally: 1000
Benign PNG images verified locally: 500
Malicious PNG images verified locally: 500
Format: PNG images
Original archive: 1000 QR Images of Malicious and Benign QR codes.rar

Attribution:
Galadima, Sefiya (2025), Dataset of 1000 Images of Malicious
and Benign QR codes 2025, Mendeley Data, Version 1.
DOI: 10.17632/cmhh7744sp.1

The original extracted images are preserved in QR_Original.
